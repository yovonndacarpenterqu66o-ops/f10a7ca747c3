// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Analyze slatewing lift"); }
int main(){
  announce();
  return lionss_run_workload("slatewing");
}
