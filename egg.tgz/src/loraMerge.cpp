// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Merge LoRA adapters"); }
int main(){
  announce();
  return lionss_run_workload("loraMerge");
}
