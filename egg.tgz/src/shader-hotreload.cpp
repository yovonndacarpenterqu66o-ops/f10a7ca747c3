// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Hot-reload shaders"); }
int main(){
  announce();
  return lionss_run_workload("shader-hotreload");
}
