// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Shrink failing case\n", stdout);
  return lionss_run_workload("prop_shrink");
}
