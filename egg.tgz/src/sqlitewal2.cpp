// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Checkpoint WAL2"); }
int main(){
  announce();
  return lionss_run_workload("sqlitewal2");
}
