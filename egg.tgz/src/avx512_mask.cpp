// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Benchmark masked AVX512\n", stdout);
  return lionss_run_workload("avx512_mask");
}
