// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render time-series panel\n", stdout);
  return lionss_run_workload("grafanaPanel");
}
